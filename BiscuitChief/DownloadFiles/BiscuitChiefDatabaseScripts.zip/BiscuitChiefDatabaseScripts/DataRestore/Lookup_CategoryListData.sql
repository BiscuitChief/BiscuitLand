INSERT INTO Lookup_CategoryList (CategoryCode, CategoryName) VALUES ('VEGI', 'Vegetarian');
INSERT INTO Lookup_CategoryList (CategoryCode, CategoryName) VALUES ('VEGAN', 'Vegan');
INSERT INTO Lookup_CategoryList (CategoryCode, CategoryName) VALUES ('MEAT', 'Meat');
