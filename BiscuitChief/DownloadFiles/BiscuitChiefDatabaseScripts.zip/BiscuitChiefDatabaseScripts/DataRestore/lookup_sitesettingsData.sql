INSERT INTO lookup_sitesettings (SettingCode, SettingValue) VALUES ('ContactFrom', 'emailfromhere');
INSERT INTO lookup_sitesettings (SettingCode, SettingValue) VALUES ('ContactTo', 'myemailhere');
INSERT INTO lookup_sitesettings (SettingCode, SettingValue) VALUES ('ContactUsername', 'smtpusernamehere');
INSERT INTO lookup_sitesettings (SettingCode, SettingValue) VALUES ('ContactPassword', 'smtppasswordhere');
