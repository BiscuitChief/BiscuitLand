CREATE PROCEDURE `Security_Select_User`(
	pUsername varchar(50)
)
BEGIN
	SELECT Username, Password, EncryptionSeed FROM Security_Users WHERE Username = pUsername;
END