CREATE PROCEDURE `Recipe_Select_RecipeSearch`(
	pSearchText varchar(200),
	pIngredients varchar(500),
	pCategories varchar(500)
)
BEGIN

	SET pSearchText = CONCAT('%',IFNULL(pSearchText, ''),'%');

	SELECT
		uuid_from_bin(RCP.RecipeID) AS RecipeID,
		RCP.Title,
		RCP.Description,
		group_concat(DISTINCT concat(CL.CategoryCode,'::',CL.CategoryName) separator '||') AS CategoryList
	FROM
		Recipe_Recipes AS RCP
		INNER JOIN Recipe_Ingredients AS ING
			ON RCP.RecipeID = ING.RecipeID
		LEFT OUTER JOIN Recipe_Categories AS RC
			ON RCP.RecipeID = RC.RecipeID
		LEFT OUTER JOIN Lookup_CategoryList AS CL
			ON RC.CategoryCode = CL.CategoryCode
	WHERE
		(RCP.Title LIKE pSearchText
			OR RCP.Description LIKE pSearchText
			OR ING.IngredientName LIKE pSearchText
			OR pIngredients LIKE CONCAT('%',IFNULL(ING.IngredientName,''),'|%'))
		AND (IFNULL(pCategories,'') = ''
			OR (IFNULL(RC.CategoryCode, '') <> '' AND pCategories LIKE CONCAT('%',RC.CategoryCode,'|%')))
	GROUP BY
		RCP.RecipeID,
		RCP.Title,
		RCP.Description
	ORDER BY RCP.Title;

END