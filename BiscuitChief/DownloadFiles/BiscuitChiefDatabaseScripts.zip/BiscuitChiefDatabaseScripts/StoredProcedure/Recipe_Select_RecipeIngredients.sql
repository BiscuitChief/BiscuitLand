CREATE PROCEDURE `Recipe_Select_RecipeIngredients`(
	pRecipeID varchar(36)
)
BEGIN
	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	SELECT
		ING.IngredientID,
		ING.RecipeID,
		ING.IngredientName,
		ING.Quantity,
		ING.UnitOfMeasure,
		ING.DisplayType,
		ING.Notes,
		ING.SortOrder
	FROM
		Recipe_Ingredients AS ING
	WHERE
		ING.RecipeID = pRecipeBinID
	ORDER BY
		ING.SortOrder,
		ING.IngredientName,
		ING.Quantity,
		ING.IngredientID;

END