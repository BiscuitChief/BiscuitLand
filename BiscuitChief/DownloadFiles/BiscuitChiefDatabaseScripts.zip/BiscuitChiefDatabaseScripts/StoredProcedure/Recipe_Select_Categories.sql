CREATE PROCEDURE `Recipe_Select_Categories`(
	pRecipeID varchar(36)
)
BEGIN
	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	SELECT
		LC.CategoryCode,
		LC.CategoryName
	FROM
		Recipe_Categories AS RC
		INNER JOIN Lookup_CategoryList AS LC
			ON RC.CategoryCode = LC.CategoryCode
	WHERE
		RC.RecipeID = pRecipeBinID
	ORDER BY
		LC.CategoryName;
END