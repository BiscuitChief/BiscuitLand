CREATE PROCEDURE `Recipe_DeleteRecipe`(
	pRecipeID varchar(36)
)
BEGIN

	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);

	DELETE FROM Recipe_Directions WHERE RecipeID = pRecipeBinID;
	DELETE FROM Recipe_Ingredients WHERE RecipeID = pRecipeBinID;
	DELETE FROM Recipe_Categories WHERE RecipeID = pRecipeBinID;
	DELETE FROM Recipe_Recipes WHERE RecipeID = pRecipeBinID;

END