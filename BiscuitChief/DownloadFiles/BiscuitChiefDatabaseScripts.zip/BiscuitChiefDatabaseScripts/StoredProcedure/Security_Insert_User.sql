CREATE PROCEDURE `Security_Insert_User`(
	pUsername varchar(50),
	pPassword varchar(50),
	pEncryptionSeed varchar(100)
)
BEGIN
	INSERT INTO Security_Users
	(
		Username,
		Password,
		EncryptionSeed
	)
	SELECT
		pUsername AS Username,
		pPassword AS Password,
		pEncryptionSeed AS EncryptionSeed;
END