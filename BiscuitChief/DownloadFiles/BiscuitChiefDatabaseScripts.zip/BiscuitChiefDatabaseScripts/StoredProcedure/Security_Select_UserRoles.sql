CREATE PROCEDURE `Security_Select_UserRoles`(
	pUsername varchar(50)

)
BEGIN
	SELECT
		CASE Users.IsAdmin WHEN 1 THEN 'ADMIN' ELSE '' END AS Rolename
	FROM
		Security_Users AS Users
	WHERE
		Users.Username = pUsername
	UNION ALL
	SELECT
		CASE Users.FullAccess WHEN 1 THEN 'FULLACCESS' ELSE '' END AS Rolename
	FROM
		Security_Users AS Users
	WHERE
		Users.Username = pUsername;
END