CREATE PROCEDURE `Recipe_SaveIngredient`(
	pIngredientID int,
	pRecipeID varchar(36),
	pIngredientName varchar(100),
	pQuantity decimal(10, 5),
	pUnitOfMeasure varchar(50),
	pNotes varchar(200),
	pDisplayType varchar(20),
	pSortOrder int,
	Out pIngredientIDOut int
)
BEGIN
	DECLARE pRecipeBinID binary(16);
	SET pRecipeBinID = uuid_to_bin(pRecipeID);
	SET pDisplayType = IFNULL(NULLIF(pDisplayType, ''), 'ING');
	SET pQuantity = NULLIF(pQuantity, 0);
	SET pUnitOfMeasure = NULLIF(pUnitOfMeasure, '');
	SET pNotes = NULLIF(pNotes, '');
	SET pIngredientIDOut = pIngredientID;

	IF IFNULL(pIngredientID, 0) > 0 AND EXISTS(SELECT IngredientID FROM Recipe_Ingredients WHERE IngredientID = pIngredientID)
	THEN
		UPDATE Recipe_Ingredients
		SET
			RecipeID = pRecipeBinID,
			IngredientName = pIngredientName,
			Quantity = pQuantity,
			UnitOfMeasure = pUnitOfMeasure,
			Notes = pNotes,
			DisplayType = pDisplayType,
			SortOrder = pSortOrder
		WHERE
			IngredientID = pIngredientID;
	ELSE
		INSERT INTO Recipe_Ingredients
		(
			RecipeID,
			IngredientName,
			Quantity,
			UnitOfMeasure,
			Notes,
			DisplayType,
			SortOrder
		)
		SELECT
			pRecipeBinID as RecipeID,
			pIngredientName as IngredientName,
			pQuantity as Quantity,
			pUnitOfMeasure as UnitOfMeasure,
			pNotes as Notes,
			pDisplayType as DisplayType,
			pSortOrder as SortOrder;

		SET pIngredientIDOut = LAST_INSERT_ID();
	END IF;


END