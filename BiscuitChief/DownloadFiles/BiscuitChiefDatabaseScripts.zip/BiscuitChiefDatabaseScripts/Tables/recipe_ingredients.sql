CREATE TABLE `recipe_ingredients` (
  `IngredientID` int(11) NOT NULL AUTO_INCREMENT,
  `RecipeID` binary(16) NOT NULL,
  `IngredientName` varchar(100) NOT NULL,
  `Quantity` decimal(10,5) DEFAULT NULL,
  `UnitOfMeasure` varchar(50) DEFAULT NULL,
  `DisplayType` varchar(20) NOT NULL DEFAULT 'ING',
  `Notes` varchar(200) DEFAULT NULL,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`IngredientID`)
) ENGINE=MyISAM AUTO_INCREMENT=655 DEFAULT CHARSET=latin1