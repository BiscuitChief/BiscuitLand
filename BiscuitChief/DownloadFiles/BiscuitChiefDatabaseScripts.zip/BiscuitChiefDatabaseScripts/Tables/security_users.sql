CREATE TABLE `security_users` (
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `EncryptionSeed` varchar(100) NOT NULL,
  `IsAdmin` tinyint(4) NOT NULL DEFAULT '0',
  `FullAccess` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1