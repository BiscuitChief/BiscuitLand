CREATE TABLE `lookup_sitesettings` (
  `SettingCode` varchar(20) NOT NULL,
  `SettingValue` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1