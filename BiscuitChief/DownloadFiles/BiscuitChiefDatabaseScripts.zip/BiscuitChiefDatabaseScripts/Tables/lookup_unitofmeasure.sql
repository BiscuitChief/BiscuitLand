CREATE TABLE `lookup_unitofmeasure` (
  `UnitOfMeasure` varchar(50) NOT NULL,
  `UnitOfMeasureText` varchar(50) NOT NULL,
  PRIMARY KEY (`UnitOfMeasure`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1