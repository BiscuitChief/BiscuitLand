CREATE TABLE `recipe_recipes` (
  `RecipeID` binary(16) NOT NULL,
  `Title` varchar(300) NOT NULL,
  `Description` longtext,
  PRIMARY KEY (`RecipeID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1